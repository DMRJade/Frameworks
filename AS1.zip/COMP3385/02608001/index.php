<?php

require 'app/autoloader.php';
require 'app/config.php';

$controller = new IndexController();
$controller->start();