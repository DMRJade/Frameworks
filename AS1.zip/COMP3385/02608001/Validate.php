<?php 
  
  
require 'app/autoloader.php';
require 'app/config.php';

    $valController = new ValidateController();
    $valController->start();