<?php

require 'app/autoloader.php';
require 'app/config.php';

$regController = new RegistrationController();
$regController->start();