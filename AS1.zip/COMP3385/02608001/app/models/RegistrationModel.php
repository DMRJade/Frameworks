<?php
class RegistrationModel extends Model implements Reader, Writer
{
 
       public function findAll(string $tablenames, array $id): array
		{
			return [];
		}
 
 
        //to test if user name already exist 
        public function find(string $tablename, array $ids) : array
        {
            if (!isset($ids['username'])   ){
             trigger_error('<b>RegistrationModel::find() error</b> Invalid input parameters',E_USER_ERROR);
            }
 
             $query = "SELECT * FROM $tablename WHERE username = '{$ids['username']}'";
                 
             if($result =  $this->sqli->query($query)){
                 if ($result->num_rows <> 1){
                     return [];
                 }
                 else {
                    return $result -> fetch_assoc();
                 }
                    
             }
             else {
                 trigger_error('RegistrationModel SQL error:</b>' .$this->sqli->error,E_USER_WARNING);
                 return [];
                }
                
         
         }
		 
		 
			 
				 
		//registerUser
		public function add(string $tablename, array $ids)			 
		 {
				  if (!isset($ids['email']) &&  !isset($ids['password']) && !isset($ids['username'])){
				 trigger_error('<b>RegistrationModel::add() error</b> Invalid input parameters',E_USER_ERROR);
				}
	 
				$role = 'Research Group Manager';
				$encryptPassword = password_hash($ids['username'], PASSWORD_DEFAULT);

				
				 $inquery = 'INSERT INTO'. tablename.'			 
						   SET username="'.$ids['username'].'",
							   email="'.$ids['email'].'",
							   password="'.$encryptPassword.'",
							   role="'.$role.'"';
							   
				 $this->sqli->query($inquery);
			   
				 if($this->sqli->errno){
					 trigger_error('RegistrationModel SQL error:</b>' .$this->sqli->error,E_USER_WARNING);
					}
		 }

  
   
 
   
   
    
}


    




















