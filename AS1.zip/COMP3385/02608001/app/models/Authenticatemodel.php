<?php
class AuthenticateModel extends Model implements Reader
{
 
 
 
        //search for one records to if it exist 
        public function find(string $tablename, array $ids) : array
        {
            if (!isset($ids['email']) &&  !isset($ids['password'])){
             trigger_error('<b>AuthenticateModel::find() error</b> Invalid input parameters',E_USER_ERROR);
            }
 
             $query = "SELECT * FROM $tablename WHERE email= '{$ids['email']}'";
                 
             if($result =  $this->sqli->query($query)){
                 if ($result->num_rows <> 1){
                     return [];
                 }
                 else {
                    return $result -> fetch_assoc();
                 }
                    
             }
             else {
                 trigger_error('AuthenticateModel SQL error:</b>' .$this->sqli->error,E_USER_WARNING);
                 return [];
                }
 
                 
         
         }

         
 
      //search for all records
      public function findAll (string $tablename, array $ids) : array
      {
             return [];

      }
 
 
 
 
 
    /*
       //search for one records
       public function find(string $tablename, array $ids) : array
       {
           if (!isset($ids['email']) &&  (!isset($ids['password']))){
            trigger_error('<b>AuthenticateModel::find() error</b> Invalid input parameters',E_USER_ERROR);
           }

            $query = "SELECT * FROM $tablename WHERE email= '{$ids['email']}'";
                
            if($result =  $this->sqli->query($query)){
                if ($result->num_rows <> 1){
                    return false;
                }
           elseif ($result->num_rows == 1){
                $row = $result -> fetch_assoc();

                if (!(password_verify($ids['password'], $row['password'])) ){
                    return false;
                }
                else {
                    return $row;

                }
                }
            }
            else {
                trigger_error('AuthenticateModel SQL error:</b>' .$this->sqli->error,E_USER_WARNING);
                }

                return [];
        
        }

        */
    


  
   
   
   
   
   
    
}


    




















