
<?php
 //database 
 const DB_USER = 'root';
 const DB_NAME = 'user_management_system';
 const DB_HOST = 'localhost';
 const DB_PASSWORD = '';


//DIRECTORIES 
const ROOT_DIR = 'C:\xampp\htdocs\COMP3385\02608001';
const VIEWS_DIR = ROOT_DIR. '\app\views';
 







 
 
 
 
 
 
 
 




