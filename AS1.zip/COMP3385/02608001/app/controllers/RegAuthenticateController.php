<?php
class RegAuthenticateController extends AbstractController
{
    private $uname;
    private $em ;
    private $role;

  
        //model
       protected function makeModel() : Model
        {
            return new RegistrationModel(DB_USER, DB_PASSWORD, DB_NAME, DB_HOST);
        }

        //empty view
        protected function makeView() : View
        {
            $v = new View();
            return $v;
        }



        public function start()
        {
            $this->model =$this->makemodel();
                
        
        }
    



   /**
     * Connect to db and check to see if username already
     * 
     * 
     */

		 public function isUsernameUnique(String $username){
			  
			 $v = new RegValidateController();
			 $validUsername = $v->isUsernameValid($username);
			
			

				if(!$validUsername  )   
					{
						return false;
					}
					
				$field = ['username' => $username];	
				$records = $this->model->find('users', $field);

				if (empty($records))
				{
					return false;
				} 
			
			else {
					self::$uname = $records['username'];
					self::$em = $records['email'];
					self::$role = $records['role'];
					return true;

				}	
					
				 
			 
		 }
		
		
        
	 public function insertRecord(array $userData) 
	 {
		 
		   $v = new RegValidateController();
		  $validinfo = $v->RegInfoValid($userData);
		  
		  if($validinfo){
		    
			$fields = ['username' => $userData['username'] ,'email' => $userData['email'], 'password'=>$userData['password']];
			$records = $this->model->add('users', $fields);
			return true;
			
		  }
		return false;	
	 }
				 
		 




	

    
}      



  


 
