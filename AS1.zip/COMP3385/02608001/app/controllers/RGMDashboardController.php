<?php

class RGMDashboardController extends AbstractController
{
   
   private $errors = [];
   
   
    protected function makeModel() : Model
    {
        return new Model(DB_USER, DB_PASSWORD, DB_NAME, DB_HOST);
    }

    protected function makeView() : View
    {
        $view = new View();
        $view->registerView(VIEWS_DIR . '/Research_Group_Manager.php');
        return $view;
    }

    public function start()
    {
        $this->view = $this->makeView();

        $this->view->display();
    }







}