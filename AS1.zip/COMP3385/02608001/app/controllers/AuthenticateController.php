<?php
class AuthenticateController extends AbstractController
{
    private $uname;
    private $em ;
    private $role;

  
        //model
       protected function makeModel() : Model
        {
            return new Authenticatemodel(DB_USER, DB_PASSWORD, DB_NAME, DB_HOST);
        }

        //empty view
        protected function makeView() : View
        {
            $v = new View();
            return $v;
        }



        public function start()
        {
            $this->model =$this->makemodel();
                
        
        }
    



   /**
     * Connect to db and check to see if email and password is found
     * 
     * 
     */

     public function authUser(String $password, string $email)
     {
        $v = new ValidateController();
        $validEmail = $v->isEmailValid($email);
        $validPassword =  $v->isPasswordValid($password);

            if(!$validEmail  ||!$validPassword)   
                {
                    return false;
                }
            
            $fields = ['email' => $email , 'password'=>$password];
            $records = $this->model->find('users', $fields);

            if (empty($records) || !password_verify($password, $records['password']))
            {
                return false;
            } 
        
        else {
                self::$uname = $records['username'];
                self::$em = $records['email'];
                self::$role = $records['role'];
                return true;

            }
        }
		
		

    
}      



  


 
