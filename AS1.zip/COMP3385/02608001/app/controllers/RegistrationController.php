<?php

class RegistrationController extends AbstractController{
    
   private $errors = [];
   
   
    protected function makeModel() : Model
    {
        return new Model(DB_USER, DB_PASSWORD, DB_NAME, DB_HOST);
    }

    protected function makeView() : View
    {
        $view = new View();
        $view->registerView(VIEWS_DIR . '/Registration.php');
        return $view;
    }

    public function start()
    {
        $this->view = $this->makeView();

        $this->view->importVar('errors', $this->errors );

        $this->view->display();
    }

    public function setErrorMessages(array $errors)
    {
        if (!empty($errors)){
            $this->errors = $errors;
        }


    }

	
	
	

}	
	
	
	
	
	
	

