<?php
class RegValidateController extends AbstractController
{

    private $errors= [];

    protected function makeModel() : Model
    {
        //empty model
        return new Model(DB_USER, DB_PASSWORD, DB_NAME, DB_HOST);
    }

    protected function makeView() : View
    {
        $v = new View();
        return $v;
    }

    public function start()
    {
       
        if ($this->RegInfoValid($_POST)){
           $this->insertRecord($_POST);
		    $indexcon = new IndexController();
           $indexcon ->start();
        }
       else{
            $regCon = new RegistrationController();
            $regCon->setErrorMessages ($this->getErrorMessages());
            $regCon ->start();
        }
       
    }
        


   public function RegInfoValid(array $userData) : bool
	   {
		  $validEmail = $this->isEmailValid($userData['email']);
		  $validPassword = $this->isPasswordValid($userData['password']);
		  $validUsername = $this->isUsernameValid($userData['username']);

		  

			if(!$validEmail  ||!$validPassword || !$validUsername){
				$this->errors['Registration Format'] = 'Invalid Input Format';
				return false;
			}

			$regauthobj = new RegAuthenticateController();
			$regauthobj->start();
			if($regauthobj->isUsernameUnique($userData['username'])){
				$this->errors['Registration'] = 'Username already exist';
				return false;
			}
			
						
			return true;

				
			}
	  
   
     
	 public function insertRecord(array $userData) 
	 {
		 
			$reginobj = new RegAuthenticateController();
			$reginobj->start();
		    
		     if($reginobj->isUsernameUnique($userData['username'])){
				 $this->errors['Registration'] = 'record inserted';
			 }
			 else 
			$this->errors['Registration'] = 'record not inserted';
 
				 
		 
	 }
   
   

  
  
    public function isUsernameValid(string $username) : bool
    {
		
		
        $Pattern = "(^[a-zA-Z0-9]{6,}$)";
           
        //check if pattern entered is correct 
        if (!preg_match($Pattern, $username)){
            $this->errors['username'] ='Username is invalid.<br>';
           return false;
        }
         
       
        return true;

    }     

  
  
  

   private function isEmailValid($email) :bool{

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
            $this->errors['Email'] = 'Email Format is Invalid';
    
            return false;
        }
        return true;
    }  


    



    public function isPasswordValid(string $passwd) : bool
    {

        $isUpLetter = false;
        $isNumber = false;
        $str = $passwd;
        
        //pattern to test length and alphanumeric
        $Pattern = "(^[A-Za-z0-9]{10,18}$)";
        
        $uppercasePattern = '/[A-Z]/';
        $numberPattern = '/[0-9]/';
        
        
        $uppercase = preg_match($uppercasePattern, $str);
        $number = preg_match($numberPattern, $str);

        //check if pattern entered is correct 
        if (!preg_match($Pattern, $str)){
            $this->errors['Password'] ='Password must be at least 10 characters and only alphanumeric.<br>';
           return false;
        }
         
        //check for uppercase letter
        if(!$uppercase){
            $this->errors['Password'] = 'Password must contain at least 1 uppercase letter.<br>';
            return false;

        }
        
        if (!$number){
            $this-> errors['Password'] = 'Password must contain at least 1 digit.<br>';
            return false;
        }

        return true;

    }     




       
   /** 
    * * displays error message
     */
        public function getErrorMessages()
        {
            $errors = $this->errors;
            return $errors;

            
        }



      







    }


















