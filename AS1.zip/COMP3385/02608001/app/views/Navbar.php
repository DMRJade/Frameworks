<nav class="navbar navbar-expand-sm bg-light navbar-light">
  <ul class="navbar-nav">
    <li class="nav-item active">
      <a class="nav-link" href="Index.php">Login</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="Register.php">Register</a>
    </li>
  </ul>
</nav>