<!DOCTYPE html>
<html>

<head>
  <title>Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-4">
            <!-- Logo in the left corner -->
            <img src="images/logo.png" alt="Logo" class="img-fluid">
        </div>
        <div class="col-md-5">
            <!-- website name -->
            <h2>Research Management System</h2>
        </div>
    </div>
       <?php
    include('Navbar.php'); // Include the Navbar
    ?>
 

    <div id="login">
        <h3 class="text-center text-white pt-5">Login form</h3>
   
        <div class="container p-3 my-3 ">
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">
                        <form id="login-form" class="form" action="Validate.php" method="post">
                            <h3 class="text-center text-info">Login</h3>
                            <div>
   
                            <?php
                                if (!empty($errors)) : ?>
                                <ul>
                                    <?php 
                                        foreach ($errors as $field=>$msg): ?>
                                        <li style="color: red; font-weight: bold;"><?php echo $field . ':'.$msg ?></li>
                                    <?php 
                                        endforeach; ?>
                                </ul>
                                    <?php 
                                        endif; ?>
                                        </div>

                            <div class="form-group">
                                <label for="email" class="text-info">Email:</label><br>
                                <input type="email" name="email" id="email" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="password" class="text-info">Password:</label><br>
                                <input type="text" name="password" id="password" class="form-control">
                            </div>
                            <div class="form-group">
                                <input type="submit" name="submit" class="btn btn-info btn-md" value="submit">
                            </div>
                           
                        </form>
                    </div>
                </div>
            </div>
        </div>
   </div>
     <?php
    include('footer.php'); // Include the footer
    ?>
</body>
</html>