<footer id="my-footer" class="mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <p>Copyright&copy; Dana Ramsey. All Rights Reserved</p>
            </div>
        </div>
    </div>
</footer>