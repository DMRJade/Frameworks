<!DOCTYPE html>
<html lang="en">
<head>
  <title>Research Group Manager Dashboard</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  
  <style>
        .square {
            border: 1px solid #ccc;
            padding: 20px;
            text-align: center;
            transition: background-color 0.3s;
        }
        .square:hover {
            background-color: #f0f0f0;
            cursor: pointer;
        }
    </style>
  
  
  
  
</head>
<body>


<div class="container mt-4">
    <div class="row">
        <div class="col-4">
            <!-- Logo -->
            <img src="../../images/logo.png" alt="Logo" class="img-fluid">
        </div>
        <div class="col-5 text-center">
            <!-- Heading in the center -->
            <h2>Research Management System</h2>
        </div>
        <div class="col-3 text-right">
            <!-- Logout Button -->
            <button class="btn btn-danger">Logout</button>
        </div>
    </div>
	

    <div class="row mt-4">
        <div class="col-7">
            <p>Research Group Manager:</p>
          
        </div>
        <div class="col-5">
            <p>Email:</p>
            
        </div>
    </div>
	
	
    <div class="row mt-4">
        <div class="col-6">
           <div class="square"><a href="#">Create New Study</a></div>
        </div>
		<div class="col-6">
           <div class="square"><a href="#">View All Studies</a></div>
        </div>
    </div>
    
    <div class="row mt-4">
        <div class="col-6">
           <div class="square"><a href="#">Delete Previous Studies</a></div>
        </div>
        <div class="col-6">
           <div class="square"><a href="#">Create New Researcher</a></div>
        </div>
    </div>
</div>
    <?php
    include('footer.php'); // Include the footer
    ?>  
</body>
</html>