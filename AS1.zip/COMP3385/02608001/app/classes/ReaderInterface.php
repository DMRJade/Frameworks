<?php
 
 interface Reader
 {
    //search for one records
    public function find(string $tablename, array $ids) : array;


    //search for all records
    public function findAll (string $tablename, array $ids) : array;





 }