<?php
 
 interface Writer
 {
    //add  records
    public function add(string $tablename, array $ids); 

 }