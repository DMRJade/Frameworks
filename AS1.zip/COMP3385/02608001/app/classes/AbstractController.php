<?php

abstract class AbstractController
{
	
    //display model = database 
	protected $model = null;
	
	//display data on the view page 
 	protected $view = null;
	
	
	//create model for controller  
	abstract protected function makeModel(): Model;
	
	//how the controller interact with the view 
	abstract protected function makeView(): View;
	
	
	//call the methods within the controller 	
	abstract public function start();
}