<?php

class View
	{
		
	  private $vars = [];
	  private $views = '';



        public function registerView(string $filename)
        {
                
                if (!file_exists($filename))
                {
                    trigger_error('Error: File ' . $filename . ' does not exist.', E_USER_ERROR);
                }
                
                if (empty($filename))
                {
                    trigger_error('Error: Please enter a filename', E_USER_ERROR);
                }
                
                $this->views = $filename;
        }


        
        public function importVar(string $name, $value)
        {
                //add valid($name) method
                
                $this->vars[$name] = $value;
        }


   //pass mutliple varibles 
       public function importVars(array $variables)
        {
                if (empty($variables))
                {
                    trigger_error('View Error: Variable Array is Empty', E_USER_ERROR);
                }
                foreach ($variables as $name=>$value)
                {
                    $this->vars[$name] = $value;
                }
                
                //add valid($name) method

        }


        //show view file 
        public function display()
        {
            extract($this->vars);
            require $this->views;

        }
}

