<?php 
  
  
require 'app/autoloader.php';
require 'app/config.php';

    $rvalController = new RegValidateController();
    $rvalController->start();